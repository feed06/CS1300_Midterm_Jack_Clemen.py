
sentence = input("Enter a sentence: ")

if sentence.strip() == "":
    print("No sentence entered.")
else:
    words = sentence.strip().split()
    total_characters = len(sentence)
    total_words = len(words)

    vowels = (sentence.lower().count("a") +
              sentence.lower().count("e") +
              sentence.lower().count("i") +
              sentence.lower().count("o") +
              sentence.lower().count("u"))

    non_space = len(sentence.replace(" ", ""))
    average_length = non_space / total_words

    first_word = words[0]
    last_word = words[-1]
    reversed_sentence = sentence[::-1]

    print("=== SENTENCE ANALYSIS ===")
    print(f"Total characters: {total_characters}")
    print(f"Total words: {total_words}")
    print(f"Number of vowels: {vowels}")
    print(f"Non-space characters: {non_space}")
    print(f"Average word length: {average_length:.2f}")
    print(f"First word: {first_word}")
    print(f"Last word: {last_word}")
    print(f"Reversed sentence: {reversed_sentence}")


