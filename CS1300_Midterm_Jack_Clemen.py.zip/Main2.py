temp = float(input("Enter temperature: "))
unit = input("Enter unit (F or C): ").upper()

if unit == "C":
    fahrenheit = temp * 9 / 5 + 32
    print(f"{fahrenheit:.2f} F")
elif unit == "F":
    celsius = (temp - 32) * 5 / 9
    print(f"{celsius:.2f} C")
else:
    print("Invalid unit.")
